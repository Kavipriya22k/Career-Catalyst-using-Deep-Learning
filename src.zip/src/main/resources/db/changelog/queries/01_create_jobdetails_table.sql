CREATE TABLE job_details (
    id bigint PRIMARY KEY auto_increment,
    company_name varchar(255),
    job_title varchar(255),
    no_of_year_experience int,
    location varchar(255),
    work_mode varchar(255),
    vacancies int,
    job_description varchar(255),
    hr_details varchar(255)

);