CREATE TABLE authentication_details (
    id bigint PRIMARY KEY auto_increment,
    user_name varchar(255),
    user_email varchar(255),
    user_mobile_num VARCHAR(10),
    user_pass VARCHAR(255),
    UNIQUE(user_email),
    UNIQUE(user_mobile_num)
);