package com.jobrecommendation.jobdetails.service;

import com.jobrecommendation.jobdetails.modal.JobDetails;
import com.jobrecommendation.jobdetails.repository.JobDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class JobDetailsService {
    @Autowired
    private JobDetailsRepository jobDetailsRepository;

    public void saveJobDetails(JobDetails jobDetails) {
        try {
            jobDetailsRepository.save(jobDetails);
        } catch (Exception e) {
            System.err.println("Error saving job details: " + e.getMessage());
        }
    }

    public List<JobDetails> getJobDetails() {
        return jobDetailsRepository.findAll();
    }

//    public List<JobDetails> matchJobs(String skills, String experienceLevel) {
//        List<JobDetails> allJobs = getJobDetails();
//        List<JobDetails> matchedJobs = new ArrayList<>();
//
//        if (skills == null || skills.trim().isEmpty() || experienceLevel == null || experienceLevel.trim().isEmpty()) {
//            throw new IllegalArgumentException("Skills and experience level must be provided");
//        }
//
//        int experience;
//        try {
//            experience = Integer.parseInt(experienceLevel);
//        } catch (NumberFormatException e) {
//            throw new IllegalArgumentException("Experience level must be a valid integer");
//        }
//
//        for (JobDetails job : allJobs) {
//            if (job.getJobTitle().toLowerCase().contains(skills.toLowerCase()) ||
//                    job.getJobDescription().toLowerCase().contains(skills.toLowerCase())) {
//                if (experience >= job.getNoOfYearExperience()) {
//                    matchedJobs.add(job);
//                }
//            }
//        }
//
//        return matchedJobs;
//    }

    public List<JobDetails> matchJobsBasedOnTextAndSkills(String extractedText, String skills, String experienceLevel) {
        List<JobDetails> allJobs = getJobDetails();
        List<JobDetails> matchedJobs = new ArrayList<>();

        // Normalize the extracted text to lowercase and split into words
        String[] resumeWords = extractedText.toLowerCase().split("\\s+"); // Words from resume
        String[] skillWords = skills != null ? skills.toLowerCase().split("\\s*,\\s*") : new String[0]; // Split by commas for skills

        // Parse experience level
        int experience = 0;
        if (experienceLevel != null && !experienceLevel.trim().isEmpty()) {
            try {
                experience = Integer.parseInt(experienceLevel.trim());
            } catch (NumberFormatException e) {
                System.err.println("Invalid experience level: " + experienceLevel);
            }
        }

        // Match jobs based on resume words, skill words, and experience
        for (JobDetails job : allJobs) {
            boolean matches = false;

            // Check if any word from the resume matches the job title or description
            for (String word : resumeWords) {
                if (job.getJobTitle().toLowerCase().contains(word) || job.getJobDescription().toLowerCase().contains(word)) {
                    matches = true;
                    break;
                }
            }

            // Check if any skill from the input matches the job title or description
            if (!matches) {
                for (String skill : skillWords) {
                    if (job.getJobTitle().toLowerCase().contains(skill) || job.getJobDescription().toLowerCase().contains(skill)) {
                        matches = true;
                        break;
                    }
                }
            }

            // If a match is found, check the experience level
            if (matches && (experience == 0 || experience >= job.getNoOfYearExperience())) {
                matchedJobs.add(job);
            }
        }

        return matchedJobs;
    }

}
