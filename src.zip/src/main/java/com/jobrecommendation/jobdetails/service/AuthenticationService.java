package com.jobrecommendation.jobdetails.service;

import com.jobrecommendation.jobdetails.modal.Authentication;
import com.jobrecommendation.jobdetails.repository.AuthenticationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthenticationService {
    @Autowired
    public AuthenticationRepository authenticationRepository;

    public void saveUserDetails(Authentication authentication) {
        System.out.println(authentication);
        try {
            authenticationRepository.save(authentication);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public List<Authentication> getUserDetails() {
        return authenticationRepository.findAll();
    }

    public Authentication findByUserEmail(String user_email) {
        return authenticationRepository.findByUserEmail(user_email);
    }


}
