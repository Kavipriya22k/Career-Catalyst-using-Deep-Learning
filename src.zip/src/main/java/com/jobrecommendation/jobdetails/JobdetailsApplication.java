package com.jobrecommendation.jobdetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobdetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobdetailsApplication.class, args);
	}

}
