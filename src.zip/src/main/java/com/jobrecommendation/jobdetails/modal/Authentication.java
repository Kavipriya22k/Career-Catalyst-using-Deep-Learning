package com.jobrecommendation.jobdetails.modal;

import jakarta.persistence.*;

@Table(name = "authentication_details")
@Entity
public class Authentication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "user_email")
    private String userEmail;

    @Column(name = "user_mobile_num")
    private String userMobileNum;

    @Column(name = "user_pass")
    private String userPass;

    public Authentication(String user_name, String user_email, String user_mobile_num, String user_pass) {
        this.userName = user_name;
        this.userEmail = user_email;
        this.userMobileNum = user_mobile_num;
        this.userPass = user_pass;
    }

    public Authentication() {
    }

    public String getUser_name() {
        return userName;
    }

    public void setUser_name(String userName) {
        this.userName = userName;
    }

    public String getUser_email() {
        return userEmail;
    }

    public void setUser_email(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUser_mobile_num() {
        return userMobileNum;
    }

    public void setUser_mobile_num(String userMobileNum) {
        this.userMobileNum = userMobileNum;
    }

    public String getUser_pass() {
        return userPass;
    }

    public void setUser_pass(String userPass) {
        this.userPass = userPass;
    }

    @Override
    public String toString() {
        return "Authentication{" +
                "user_name='" + userName + '\'' +
                ", user_email='" + userEmail + '\'' +
                ", user_mobile_num='" + userMobileNum + '\'' +
                ", user_pass='" + userPass + '\'' +
                '}';
    }
}
