package com.jobrecommendation.jobdetails.modal;

import jakarta.persistence.*;

@Table(name = "job_details")
@Entity
public class JobDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    private Long id;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "job_title")
    private String jobTitle;

    @Column(name = "no_of_year_experience")
    private int noOfYearExperience;

    @Column(name = "location")
    private String location;

    @Column(name = "work_mode")
    private String workMode;

    @Column(name = "vacancies")
    private int vacancies;

    @Column(name = "job_description")
    private String jobDescription;

    @Column(name = "hr_details")
    private String hrDetails;

    // Constructors, getters, and setters...

    public JobDetails() {
    }
    public JobDetails(Long id, String companyName, String jobTitle, int noOfYearExperience, String location, String workMode, int vacancies, String jobDescription, String hrDetails) {
        this.id = id;
        this.companyName = companyName;
        this.jobTitle = jobTitle;
        this.noOfYearExperience = noOfYearExperience;
        this.location = location;
        this.workMode = workMode;
        this.vacancies = vacancies;
        this.jobDescription = jobDescription;
        this.hrDetails = hrDetails;
    }

    @Override
    public String toString() {
        return "JobDetails{" +
                "id=" + id +
                ", companyName='" + companyName + '\'' +
                ", jobTitle='" + jobTitle + '\'' +
                ", noOfYearExperience=" + noOfYearExperience +
                ", location='" + location + '\'' +
                ", workMode='" + workMode + '\'' +
                ", vacancies=" + vacancies +
                ", jobDescription='" + jobDescription + '\'' +
                ", hrDetails='" + hrDetails + '\'' +
                '}';
    }

    public Long getid() {
        return id;
    }

    public void setid(Long id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public int getNoOfYearExperience() {
        return noOfYearExperience;
    }

    public void setNoOfYearExperience(int noOfYearExperience) {
        this.noOfYearExperience = noOfYearExperience;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getWorkMode() {
        return workMode;
    }

    public void setWorkMode(String workMode) {
        this.workMode = workMode;
    }

    public int getVacancies() {
        return vacancies;
    }

    public void setVacancies(int vacancies) {
        this.vacancies = vacancies;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public String getHrDetails() {
        return hrDetails;
    }

    public void setHrDetails(String hrDetails) {
        this.hrDetails = hrDetails;
    }
}
