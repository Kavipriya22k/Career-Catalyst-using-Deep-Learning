package com.jobrecommendation.jobdetails.controller;


import com.jobrecommendation.jobdetails.modal.JobDetails;
import com.jobrecommendation.jobdetails.service.JobDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000") // Adjust as needed
@RestController
@RequestMapping("/jobDetails")
public class JobDetailsController {
    @Autowired
    private JobDetailsService jobDetailsService;

    @PostMapping("/add")
    public String add(@RequestBody JobDetails jobDetails){
        jobDetailsService.saveJobDetails(jobDetails);
        return "New job is added";
    }
    @GetMapping("/getAll")
    public List<JobDetails> getJobDetails(){
        return jobDetailsService.getJobDetails();
    }


//    @PostMapping("/matchJobs")
//    public List<JobDetails> matchJobs(@RequestBody Map<String, String> payload) {
//        String extractedText = payload.get("extractedText");
//        String skills = payload.get("skills"); // Optional
//        String experienceLevel = payload.get("experienceLevel"); // Optional
//
//        return jobDetailsService.matchJobs(extractedText, skills, experienceLevel);
//    }
@PostMapping("/matchJobs")
public List<JobDetails> matchJobs(@RequestBody Map<String, String> payload) {
    String extractedText = payload.get("extractedText");
    String skills = payload.get("skills");
    String experienceLevel = payload.get("experienceLevel");

    return jobDetailsService.matchJobsBasedOnTextAndSkills(extractedText, skills, experienceLevel);
}

}
