package com.jobrecommendation.jobdetails.controller;

import com.jobrecommendation.jobdetails.modal.Authentication;
import com.jobrecommendation.jobdetails.service.AuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/authentication")
@CrossOrigin
public class AuthenticationController {

    @Autowired
    private AuthenticationService authenticationService;

    @PostMapping("/add")
    public String add(@RequestBody Authentication authenticationDetails) {
        authenticationService.saveUserDetails(authenticationDetails);
        return "{\"message\": \"New User is added\"}";
    }

    @GetMapping("/getAll")
    public List<Authentication> getUserDetails() {
        return authenticationService.getUserDetails();
    }

    @PostMapping("/login")
    public boolean login(@RequestBody Authentication loginDetails) {
        Authentication user = authenticationService.findByUserEmail(loginDetails.getUser_email());
        return user != null && user.getUser_pass().equals(loginDetails.getUser_pass());
    }


}
